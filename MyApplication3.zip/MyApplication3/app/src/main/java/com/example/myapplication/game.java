package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONException;

import java.util.HashMap;
import java.util.Map;


public class game extends AppCompatActivity {

    static public int i;
    static public String maquestion="";
    JSONObject choix = new JSONObject();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game);


        Button bouttonNext = findViewById(R.id.ButtonNext);
        TextView TexteQuestion = findViewById(R.id.TexteQuestion);

        i=0;



        /*

        RequestQueue queue = Volley.newRequestQueue(this);
            String url = "http://192.168.1.5/monsitephp/PhpProject1/api/getQuestions.php";

            JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                    new Response.Listener<JSONObject>() {

                        @Override
                        public void onResponse(JSONObject response) {
                            Log.e("DEV1111",response.toString());
                            try {
                                response.getJSONObject("0");
                                JSONArray jsonArray = response.getJSONArray("");

                                for (int i = 0; i < jsonArray.length(); i++){
                                    JSONObject question = jsonArray.getJSONObject(i);
                                    String intitule = question.getString("intitule");

                                    bouttonNext.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View view) {
                                            Log.e("DEVE0304", "Button clicked");


                                            TexteQuestion.setText(intitule);

                                        }
                                    });
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                    }, new Response.ErrorListener(){
                    @Override
                public void onErrorResponse(VolleyError error){
                        error.printStackTrace();
                        }

                    });
        queue.add(request);


         */
    }





    public void runRestRequest(View view){

        Button bouttonNext = findViewById(R.id.ButtonNext);
        TextView TexteQuestion = findViewById(R.id.TexteQuestion);

        Log.e("DEVE0304", "MainActivity.runRestRequest()");

        // !!!! Add dependencie in build.gradle : https://developer.android.com/training/volley/index.html

        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        String url ="https://www.google.com";
        url = "http://192.168.1.5/monsitephp/PhpProject1/api/getQuestions.php";


        // Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Display the response string.
                        Log.e("DEVE0304", "Request answer : " + response);

                        Log.e("DEVE0544", "val: "+i);


                        bouttonNext.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Log.e("DEVE0304", "Button clicked");
                                Log.e("DEVE0555", "val: "+i);
                                Log.e("test",response);

                                try{
                                    JSONArray myArray = new JSONArray(response);

                                    JSONObject question = myArray.getJSONObject(i);
                                    String intitule = question.getString("intitule");
                                    maquestion=""+i;

                                    TexteQuestion.setText(intitule);

                                    Log.e("TEST", question.toString());

                                    if (i < myArray.length()-1 && !choix.isNull(maquestion)) {
                                        i++;
                                    }
                                    else{
                                        Log.e("MESREPONSES", "Reponse : " + choix);
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }


                            }
                        });



                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("DEVE0304", "Request answer : Failed");
            }
        });



        // Add the request to the RequestQueue.
        queue.add(stringRequest);
    };

    public void choixoui(View view){
        try {
            choix.put(maquestion,1);
            Log.e("DEVE0301", "index " + maquestion + " reponse: " + choix.getInt(maquestion));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void choixnon(View view){
        try {
            choix.put(maquestion,0);
            Log.e("DEVE0304", "index " + maquestion + " reponse: " + choix.getInt(maquestion));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void runRestRequest2(View view){


        Log.e("DEVE0304", "nnnnnnnnnnnnnnn");

        // !!!! Add dependencie in build.gradle : https://developer.android.com/training/volley/index.html

        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        String url ="https://www.google.com";
        url = "http://192.168.1.5/monsitephp/PhpProject1/api/trouverinconnue.php?id="+choix;


        // Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                        // Display the response string.
                        Log.e("DEVE0304", "Request answer : " + response);

                Intent intent = new Intent(view.getContext(), resultat.class);
                intent.putExtra("resultat", response);
                view.getContext().startActivity(intent);


                    }
                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("DEVE0304", "Request answer : Failed");
            }
        }




        );

        // Add the request to the RequestQueue.
        queue.add(stringRequest);





    };

}